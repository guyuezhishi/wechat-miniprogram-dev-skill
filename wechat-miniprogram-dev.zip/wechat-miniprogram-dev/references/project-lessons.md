# Project Lessons: Local Asset Tracker

These patterns came from iterative work on a personal asset-recording Mini Program. They are reusable interaction/data-flow lessons, not mandatory features for other products.

## Navigation and information layout

- Use short, labeled sections or tabs when a long page requires repeated scrolling. Keep frequently used destinations easy to reach; place infrequent records or actions lower in the hierarchy.
- A category summary should navigate to the matching filtered list. Pass the target category as a page parameter and validate it against supported filters.
- Keep a clear “All” state. If a list is large, render a small initial slice and provide an explicit expand/collapse action without navigating away.
- Consolidate related views where that reduces navigation, but preserve meaningful distinctions and user-recognizable names.
- Make high-frequency add actions reachable from persistent navigation where appropriate; avoid duplicating prominent add buttons on the page without a clear benefit.

## Lifecycle and totals

- Model lifecycle changes explicitly. For a rollover/replacement, close the source record at the agreed cutoff, preserve it in a history view, and count the replacement from its own start date.
- Separate “closed” from “historical rollover” if the UI treats settled records differently. Excluding a replaced source from active totals must not erase its accrued-interest history.
- For recurring or renewed products, make renewal behavior explicit and default conservatively. Test both principal treatment and interest-estimation cutoff after maturity.
- Deletion from a secondary/history list must update the same source of truth as deletion from the main list. Confirm destructive actions, refresh derived counts/totals, and keep undo behavior consistent.
- Older local records can outlive UI renames. Normalize display and filter behavior, and test that editing old records does not silently lose data.

## Charts and verification

- Place a chart where its context is clear (for example, a trend below an overview), and group related breakdowns rather than extending one long page.
- Test totals against hand-computed fixtures. Include current, expired, future, closed, renewed, rolled-over, legacy, and empty records.
- Verify the entire interaction path: tile tap → correct query parameter → correct selected tab → filtered result → correct total.
- A mocked Node test validates business logic only. It does not validate WXML compilation, native picker behavior, canvas rendering, scrolling, touch gestures, or device layout.
