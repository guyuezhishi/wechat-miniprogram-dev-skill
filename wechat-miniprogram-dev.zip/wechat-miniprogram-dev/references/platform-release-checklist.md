# Platform, Privacy, and Release Checklist

WeChat account eligibility, categories, privacy rules, API requirements, review and release procedures can change. Use this as a verification checklist, not as a statement of current eligibility or guaranteed approval.

## Before implementation or release

- Confirm the target Mini Program type, account主体, intended audience, service category, and required capabilities in the current WeChat public platform console and official documentation.
- Inventory APIs and components that may access user data or device resources: profile/phone, location, address, photos/video, files, clipboard, microphone, Bluetooth, and subscription messaging. Explain each use in the product and privacy materials where required.
- When a privacy-sensitive API is present, follow the current official privacy-authorization flow and configure the corresponding privacy statement in the account console. Do not assume a hidden or unregistered page makes retained code harmless; remove unused code or account for it deliberately.
- Search the release tree for real AppIDs where inappropriate, credentials, tokens, personal records, developer machine paths, private configs, logs, test fixtures, and unused pages. Keep secrets out of Git history, not merely out of the final README.
- Review package size, page registration, components, permissions, network destinations, data retention/deletion behavior, and `packOptions`.

## Test and release

- Run project syntax/config checks and the repository's tests. Check all routes, WXML events, empty/error states, and data boundaries.
- Compile with the target WeChat Developer Tools version. Exercise critical paths in the simulator and, where available, on a real device; record which checks were actually completed.
- Uploading a development version, setting an experience version, submitting for review, and releasing to all users are separate actions. Do not claim approval or release until the console confirms it.
- Recheck the current official requirements immediately before account changes, privacy declarations, upload, review, and release. Avoid promising processing times.

## Official starting points

- [WeChat Mini Program Developer Documentation](https://developers.weixin.qq.com/miniprogram/dev/framework/)
- [WeChat Mini Program API Documentation](https://developers.weixin.qq.com/miniprogram/dev/api/)
- [WeChat Public Platform](https://mp.weixin.qq.com/)
