# Optional Cloud Storage and Subscription Messages

Use this reference only when the product requires cross-device data, shared backend state, or user-requested scheduled notifications. A personal/offline tool may be complete with local storage alone.

## Cloud storage

- Decide what must sync, how users are identified, how data is exported/deleted, and what ongoing costs or operational dependencies are acceptable.
- Configure the cloud environment and database from the user's account console. Do not assume a collection is private by default; verify the current access rules and test cross-user access boundaries.
- Keep environment IDs and other deployment values in local/private config where appropriate. Never commit credentials, private keys, or real user records.
- Design for network failures, duplicate submissions, partial migration, and local/cloud mode differences. Test these explicitly before enabling cloud mode for real users.

## Subscription messages

- Verify the currently supported message type, template fields, authorization flow, and delivery constraints in official WeChat docs and the account console before implementation.
- Request a subscription only in response to the user's clear action, handle refusal/cancellation, and do not imply that a request guarantees delivery.
- A scheduled notification generally needs a server-side scheduler or cloud function; a Mini Program page cannot be relied on to run in the background at a fixed time.
- Store only the minimum data required for the reminder. Define expiry, revocation, duplicate-send handling, and user-visible disable controls.

Official starting points: [Mini Program cloud development documentation](https://developers.weixin.qq.com/miniprogram/dev/wxcloud/basis/getting-started.html) and [Mini Program API documentation](https://developers.weixin.qq.com/miniprogram/dev/api/).
