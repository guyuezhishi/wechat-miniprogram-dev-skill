# Mini Program Troubleshooting

## Developer Tools and project configuration

- If the editor does not reflect changed configuration, use the Developer Tools compile/reload action and inspect page-level JSON; page configuration may override app-wide window settings.
- If a command-line interface cannot connect, check the current Developer Tools security/service-port settings and whether the desktop app is running. Prefer the official installer and documentation over old package-manager workarounds.
- Confirm every route in `app.json` has the expected page files and every custom component is declared where used.

## Native UI and rendering

- Native pickers, switches, system navigation, and permission prompts have platform-controlled appearance. Use custom UI only when it improves the interaction and test it on device.
- For 2D canvas charts, obtain the canvas node through a selector query scoped to the page, size the backing canvas for device pixel ratio, and verify after tab/section changes and page relayout.
- Touch gestures should distinguish horizontal swipes from vertical scrolling, clamp movement, and be checked on a real device; simulator gestures are not sufficient evidence.
- When a page seems blank, inspect console errors, route registration, component registration, asynchronous data failures, and conditional WXML branches.

## Assets and dates

- Use original or properly licensed images. Do not remove attribution or watermarks unless the asset license and creator expressly permit it.
- Check date arithmetic at month ends, leap days, local time zone boundaries, same-day expiry, and invalid dates. Prefer explicit local-date parsing over relying on platform-specific parsing of date-only strings.
- Format numeric input after normalizing separators; reject invalid, non-finite, zero, or negative values where the product requires positive amounts.
