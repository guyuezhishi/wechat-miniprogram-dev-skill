---
name: wechat-miniprogram-dev
description: Develop, review, test, and prepare native WeChat Mini Programs. Use when creating a Mini Program, changing an existing feature, debugging its pages or data flow, or preparing a user-requested release; do not force this workflow onto other frameworks.
metadata:
  short-description: Native WeChat Mini Program development
---

# WeChat Mini Program Development

Use this skill to deliver a coherent Mini Program feature while preserving the existing project and the user's chosen scope. The included scaffold is optional; it is not a replacement for inspecting an existing app.

## Workflow

1. **Discover the project.** Read applicable `AGENTS.md` files and repository guidance. Confirm the authoritative source directory, framework, routes, data model, and available test/build tools. Treat screenshots and generated files as references only when the user says code is authoritative. Do not replace an existing architecture with the included scaffold.
2. **Define a small vertical slice.** Identify the user journey, entry point, resulting page/state, data changes, empty/error states, and acceptance checks. For navigation from a summary or category tile, carry the selected filter or record identifier into the destination rather than making the user repeat the choice.
3. **Choose data and privacy boundaries.** Prefer the simplest storage model that meets the user need. Local storage is device/app-local, not an account sync or backup. Cloud storage is optional; never assume data isolation without verifying database permissions and identity behavior. Do not add accounts, analytics, cloud, backup, or permissions without need and user direction.
4. **Implement incrementally.** Match the existing native Mini Program conventions, keep changes focused, preserve unrelated behavior, and include accessible labels and useful empty/loading/error states. Keep destructive actions explicit; provide undo when the surrounding product uses it.
5. **Verify the whole journey.** Run syntax and JSON checks, confirm registered routes and WXML event handlers, then simulate relevant data boundaries (empty data, old records, expired/current/future dates, closed records, category filters, and navigation parameters). Use WeChat Developer Tools and a real device when available. Distinguish mocked logic checks from actual platform rendering; never claim a build or device test that was not run.
6. **Check privacy and release requirements.** Search for privacy-sensitive APIs and components, file/media/location/profile/phone access, network destinations, secrets, and unused pages. Before account, privacy, category, review, upload, or release decisions, verify current WeChat documentation and the user's account console. The user handles passwords, verification codes, administrator scans, and other account secrets.
7. **Close the loop.** Summarize changed behavior, checks actually run, remaining manual/platform checks, and known limitations. Do not imply approval, compliance, or publication without evidence.

## Focused References

- Read [references/project-lessons.md](references/project-lessons.md) for reusable interaction and data-lifecycle lessons from an anonymized local asset-tracker project. Treat its product choices as examples, not defaults.
- Read [references/platform-release-checklist.md](references/platform-release-checklist.md) for privacy, packaging, upload, review, and release checks.
- Read [references/cloud-and-subscriptions.md](references/cloud-and-subscriptions.md) only when the user asks for cloud storage or scheduled subscription messages.
- Read [references/troubleshooting.md](references/troubleshooting.md) when diagnosing Developer Tools, native components, canvas, or device-specific behavior.
- Use [assets/wx-template/](assets/wx-template/) only when a user wants a small native starter. Replace placeholders and verify current base-library/API compatibility before use.
