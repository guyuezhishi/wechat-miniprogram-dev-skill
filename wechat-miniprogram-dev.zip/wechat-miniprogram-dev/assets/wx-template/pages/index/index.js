const store = require('../../utils/store');

Page({
  data: {
    records: []
  },

  onShow() {
    // store 为 Promise 接口（本地/云双模式），数据获取写法示例：
    store.getRecords().then(list => {
      this.setData({ records: list });
    });
  }
});
