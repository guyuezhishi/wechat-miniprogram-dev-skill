const config = require('./utils/config');

App({
  onLaunch() {
    if (config.CLOUD_ENV && wx.cloud) {
      wx.cloud.init({
        env: config.CLOUD_ENV,
        traceUser: true
      });
    }
  }
});
