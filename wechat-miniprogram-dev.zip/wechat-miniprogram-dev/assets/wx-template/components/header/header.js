Component({
  data: {
    statusBarHeight: 20
  },
  lifetimes: {
    attached() {
      const info = wx.getWindowInfo ? wx.getWindowInfo() : {};
      this.setData({ statusBarHeight: info.statusBarHeight || 20 });
    }
  }
});
