// 数据存储层：本地 / 云开发双模式
// - 本地模式：数据存 wx.Storage，仅在当前设备和应用安装中，不会自动同步或备份
// - 云端模式：config.CLOUD_ENV 填入环境 ID 后启用，记录存云数据库 records 集合，
//   必须在控制台配置并验证符合需求的数据库访问规则
// 所有方法返回 Promise，页面层无感切换
const config = require('./config');

const KEY = 'asset_records_v1';
let _db = null;

function useCloud() {
  return !!(config.CLOUD_ENV && wx.cloud);
}

function col() {
  if (!_db) _db = wx.cloud.database();
  return _db.collection('records');
}

function genId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

// 云端文档 _id → 统一为 id
function normalize(doc) {
  if (doc && doc._id) {
    doc.id = doc._id;
    delete doc._id;
  }
  return doc;
}

function getRecords() {
  if (useCloud()) {
    return col().orderBy('endDate', 'asc').limit(100).get()
      .then(res => res.data.map(normalize));
  }
  return Promise.resolve(wx.getStorageSync(KEY) || []);
}

function getRecord(id) {
  if (useCloud()) {
    return col().doc(id).get().then(res => normalize(res.data));
  }
  const list = wx.getStorageSync(KEY) || [];
  return Promise.resolve(list.find(r => r.id === id));
}

function addRecord(rec) {
  if (useCloud()) {
    const data = Object.assign({}, rec, { createdAt: Date.now() });
    delete data.id;
    return col().add({ data }).then(res => {
      rec.id = res._id;
      return rec;
    });
  }
  const list = wx.getStorageSync(KEY) || [];
  rec.id = genId();
  rec.createdAt = Date.now();
  list.push(rec);
  wx.setStorageSync(KEY, list);
  return Promise.resolve(rec);
}

function updateRecord(rec) {
  if (useCloud()) {
    const data = Object.assign({}, rec);
    delete data.id;
    delete data.createdAt;
    return col().doc(rec.id).update({ data }).then(() => rec);
  }
  const list = (wx.getStorageSync(KEY) || [])
    .map(r => (r.id === rec.id ? Object.assign({}, r, rec) : r));
  wx.setStorageSync(KEY, list);
  return Promise.resolve(rec);
}

function rolloverRecord(oldId, rec, cutoffDate) {
  if (useCloud()) return Promise.reject(new Error('云端暂不支持自动另存'));
  try {
    const list = wx.getStorageSync(KEY) || [];
    const oldRecord = list.find(item => item.id === oldId);
    if (!oldRecord || oldRecord.closed) return Promise.reject(new Error('原记录不存在或已截止'));

    const now = Date.now();
    const nextRecord = Object.assign({}, rec, {
      id: genId(),
      createdAt: now,
      rolledFromId: oldId
    });
    const lastActiveDate = new Date(cutoffDate + 'T00:00:00');
    lastActiveDate.setDate(lastActiveDate.getDate() - 1);
    const interestCutoff = lastActiveDate.getFullYear() + '-' +
      String(lastActiveDate.getMonth() + 1).padStart(2, '0') + '-' +
      String(lastActiveDate.getDate()).padStart(2, '0');
    const interestEndDate = oldRecord.endDate && oldRecord.endDate < interestCutoff
      ? oldRecord.endDate
      : interestCutoff;
    const updatedRecords = list.map(item => item.id === oldId
      ? Object.assign({}, item, {
        closed: true,
        interestEndDate,
        closedAt: now,
        closedReason: 'rolled_over',
        rolloverToId: nextRecord.id
      })
      : item);
    updatedRecords.push(nextRecord);
    wx.setStorageSync(KEY, updatedRecords);
    Object.assign(rec, nextRecord);
    return Promise.resolve(rec);
  } catch (error) {
    return Promise.reject(error);
  }
}

function deleteRecord(id) {
  if (useCloud()) {
    return col().doc(id).remove();
  }
  const list = (wx.getStorageSync(KEY) || []).filter(r => r.id !== id);
  wx.setStorageSync(KEY, list);
  return Promise.resolve();
}

function restoreRecord(rec) {
  if (useCloud()) {
    const data = Object.assign({}, rec);
    delete data.id;
    delete data._id;
    delete data._openid;
    return col().add({ data }).then(res => {
      rec.id = res._id;
      return rec;
    });
  }
  const list = wx.getStorageSync(KEY) || [];
  if (!list.some(item => item.id === rec.id)) list.push(rec);
  wx.setStorageSync(KEY, list);
  return Promise.resolve(rec);
}

function isCloudMode() {
  return useCloud();
}

module.exports = {
  getRecords,
  getRecord,
  addRecord,
  updateRecord,
  rolloverRecord,
  deleteRecord,
  restoreRecord,
  isCloudMode
};
