// Leave empty to use device/app-local storage. Local data is not synced or backed up.
// Configure a cloud environment only when the product needs it, then verify its current
// database access rules and identity behavior in the WeChat console.
module.exports = {
  CLOUD_ENV: '',
  SUBSCRIBE_TMPL_ID: ''
};
