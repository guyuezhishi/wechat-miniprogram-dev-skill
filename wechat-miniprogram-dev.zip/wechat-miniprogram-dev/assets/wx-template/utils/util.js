function pad(n) {
  return String(n).padStart(2, '0');
}

function todayStr() {
  const d = new Date();
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}

// 目标日期距离今天的天数（负数表示已过期）
function daysFromToday(dateStr) {
  const t = new Date(todayStr());
  const d = new Date(dateStr);
  return Math.round((d - t) / 86400000);
}

// 较长的倒计时按 30 天折合为月，并保留剩余天数
function remainingText(days) {
  if (days <= 30) return days + '天后到期';
  const months = Math.floor(days / 30);
  const extraDays = days % 30;
  return months + '个月' + (extraDays ? extraDays + '天' : '') + '后到期';
}

// 金额格式化：千分位 + 两位小数
function fmtMoney(n) {
  return Number(n || 0).toLocaleString('zh-CN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

// 金额简写：大于1万显示 x.x万
function fmtShort(n) {
  if (n >= 10000) return (n / 10000).toFixed(1) + '万';
  return String(Math.round(n));
}

// 人民币大写：1234.56 → 壹仟贰佰叁拾肆元伍角陆分
function toChineseUpper(n) {
  const value = Number(n);
  if (!isFinite(value)) return '';
  const digits = '零壹贰叁肆伍陆柒捌玖';
  const integerUnits = ['', '拾', '佰', '仟'];
  const sectionUnits = ['', '万', '亿', '兆'];
  const amount = Math.round(Math.abs(value) * 100);
  let integer = Math.floor(amount / 100);
  const jiao = Math.floor(amount / 10) % 10;
  const fen = amount % 10;

  function sectionText(section) {
    let text = '';
    let zeroPending = false;
    for (let i = 0; i < 4 && section > 0; i++) {
      const digit = section % 10;
      if (digit === 0) {
        if (text) zeroPending = true;
      } else {
        text = digits[digit] + integerUnits[i] + (zeroPending ? '零' : '') + text;
        zeroPending = false;
      }
      section = Math.floor(section / 10);
    }
    return text;
  }

  let integerText = '';
  let sectionIndex = 0;
  let pendingZero = false;
  while (integer > 0) {
    const section = integer % 10000;
    if (section === 0) {
      if (integerText) pendingZero = true;
    } else {
      const sectionPart = sectionText(section) + sectionUnits[sectionIndex];
      integerText = sectionPart + (pendingZero || (section < 1000 && integerText) ? '零' : '') + integerText;
      pendingZero = false;
    }
    integer = Math.floor(integer / 10000);
    sectionIndex++;
  }
  integerText = integerText || '零';
  let fractionText = '';
  if (jiao) fractionText += digits[jiao] + '角';
  else if (fen) fractionText += '零';
  if (fen) fractionText += digits[fen] + '分';
  return (value < 0 ? '负' : '') + integerText + '元' + (fractionText || '整');
}

// 输入中的金额格式化：加千分位，返回 { display, num }
function fmtAmountInput(value) {
  let raw = String(value || '').replace(/,/g, '').replace(/[^\d.]/g, '');
  const firstDot = raw.indexOf('.');
  if (firstDot >= 0) {
    raw = raw.slice(0, firstDot + 1) + raw.slice(firstDot + 1).replace(/\./g, '');
  }
  const parts = raw.split('.');
  let int = (parts[0] || '').slice(0, 10);
  let dec = parts.length > 1 ? parts[1].slice(0, 2) : undefined;
  const intFmt = int.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  const display = dec === undefined ? intFmt : intFmt + '.' + dec;
  return { display, num: parseFloat(raw) || 0 };
}

// 在日期上加存期：'1个月'/'3个月'/'6个月'/'1年'/'2年'/'3年'/'5年'
function addDuration(dateStr, label) {
  const d = new Date(dateStr + 'T00:00:00');
  const day = d.getDate();
  const map = {
    '1个月': [0, 1], '3个月': [0, 3], '6个月': [0, 6],
    '1年': [1, 0], '2年': [2, 0], '3年': [3, 0], '5年': [5, 0]
  };
  const dm = map[label] || [0, 0];
  d.setFullYear(d.getFullYear() + dm[0]);
  d.setMonth(d.getMonth() + dm[1]);
  if (d.getDate() !== day) d.setDate(0); // 月末溢出取目标月最后一天
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}

// 两个日期间隔的可读文本：1年3个月5天
function diffText(startStr, endStr) {
  if (!startStr || !endStr) return '';
  const s = new Date(startStr + 'T00:00:00');
  const e = new Date(endStr + 'T00:00:00');
  if (isNaN(s) || isNaN(e) || e < s) return '';
  let y = e.getFullYear() - s.getFullYear();
  let m = e.getMonth() - s.getMonth();
  let d = e.getDate() - s.getDate();
  if (d < 0) {
    m--;
    d += new Date(e.getFullYear(), e.getMonth(), 0).getDate();
  }
  if (m < 0) {
    y--;
    m += 12;
  }
  let t = '';
  if (y) t += y + '年';
  if (m) t += m + '个月';
  if (d) t += d + '天';
  return t || '当天';
}

// ---- 收益估算：统一按单利计算 ----
// 按存入日、到期日和结清日估算；续存记录按当前利率延续估算
function incomeItems(list) {
  const items = [];
  (list || []).forEach(r => {
    if (r.closed && !r.interestEndDate) return;
    const rate = parseFloat(r.rate);
    if (!rate || rate <= 0 || !r.startDate) return;
    items.push({
      from: r.startDate,
      to: r.interestEndDate || (r.renewAtMaturity ? '9999-12-31' : (r.endDate || '9999-12-31')),
      amount: r.amount,
      dailyRate: rate / 100 / 365
    });
  });
  return items;
}

// 某一天的总收益
function incomeOfDay(items, ds) {
  let s = 0;
  items.forEach(it => {
    if (ds < it.from || ds > it.to) return;
    s += it.amount * it.dailyRate;
  });
  return s;
}

// 某月日历格子：周日开头、一行七列，前后空格补齐整周
function monthCells(items, year, month) {
  const first = new Date(year, month - 1, 1);
  const daysInMonth = new Date(year, month, 0).getDate();
  const startDow = first.getDay(); // 周日=0
  const today = todayStr();
  const cells = [];
  for (let i = 0; i < startDow; i++) {
    cells.push({ day: '', inMonth: false, income: 0 });
  }
  for (let d = 1; d <= daysInMonth; d++) {
    const ds = year + '-' + pad(month) + '-' + pad(d);
    cells.push({
      day: d,
      date: ds,
      inMonth: true,
      isToday: ds === today,
      income: incomeOfDay(items, ds)
    });
  }
  while (cells.length % 7 !== 0) {
    cells.push({ day: '', inMonth: false, income: 0 });
  }
  return cells;
}

// 某年 12 个月每月收益合计
function yearIncome(items, year) {
  const sums = new Array(12).fill(0);
  const cursor = new Date(year, 0, 1);
  while (cursor.getFullYear() === year) {
    const ds = year + '-' + pad(cursor.getMonth() + 1) + '-' + pad(cursor.getDate());
    sums[cursor.getMonth()] += incomeOfDay(items, ds);
    cursor.setDate(cursor.getDate() + 1);
  }
  return sums;
}

module.exports = {
  pad,
  todayStr,
  daysFromToday,
  remainingText,
  fmtMoney,
  fmtShort,
  toChineseUpper,
  fmtAmountInput,
  addDuration,
  diffText,
  incomeItems,
  incomeOfDay,
  monthCells,
  yearIncome
};
